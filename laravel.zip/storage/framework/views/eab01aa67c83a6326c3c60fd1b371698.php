<div class="grid grid-cols-1 md:grid-cols-3 gap-4 h-full w-full">
    <!-- Form -->
    <div class="col-span-1 p-6 bg-white dark:bg-neutral-900 rounded-lg shadow border dark:border-neutral-700">
        <h2 class="text-lg font-bold mb-4 text-gray-900 dark:text-white">
            <?php echo e($id ? 'Edit Konselor' : 'Tambah Konselor'); ?>

        </h2>

        <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="mb-4 text-green-700 dark:text-green-300"><?php echo e(session('success')); ?></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <form wire:submit.prevent="save" class="space-y-4">
            <div>
                <label class="block text-sm text-gray-700 dark:text-gray-300">Nama</label>
                <input type="text" wire:model.defer="name" class="input" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div>
                <label class="block text-sm text-gray-700 dark:text-gray-300">Email</label>
                <input type="email" wire:model.defer="email" class="input" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div>
                <label class="block text-sm text-gray-700 dark:text-gray-300">Password</label>
                <input type="password" wire:model.defer="password" class="input" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div>
                <label class="block text-sm text-gray-700 dark:text-gray-300">Konfirmasi Password</label>
                <input type="password" wire:model.defer="password_confirmation" class="input" />
            </div>

            <div>
                <button type="submit" class="btn-primary w-full">
                    <?php echo e($userId ? 'Update' : 'Simpan'); ?>

                </button>
            </div>
        </form>
    </div>

    <!-- List Data -->
    <div class="col-span-2 p-6 bg-white dark:bg-neutral-900 rounded-lg shadow border dark:border-neutral-700">
        <h2 class="text-lg font-bold mb-4 text-gray-900 dark:text-white">List Konselor</h2>

        <table class="min-w-full divide-y divide-gray-200 dark:divide-neutral-700">
            <thead class="bg-gray-100 dark:bg-neutral-800">
                <tr>
                    <th class="px-4 py-2">Nama</th>
                    <th class="px-4 py-2">Email</th>
                    <th class="px-4 py-2">Role</th>
                    <th class="px-4 py-2">Action</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 dark:divide-neutral-800">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-4 py-2"><?php echo e($user->name); ?></td>
                        <td class="px-4 py-2"><?php echo e($user->email); ?></td>
                        <td class="px-4 py-2"><?php echo e($user->role); ?></td>
                        <td class="px-4 py-2 flex space-x-2">
                            <button wire:click="edit(<?php echo e($user->id); ?>)" class="text-blue-500 hover:text-blue-700">
                                ✏️
                            </button>
                            <button wire:click="delete(<?php echo e($user->id); ?>)" onclick="return confirm('Yakin hapus?')" class="text-red-500 hover:text-red-700">
                                🗑️
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
</div>

<style>
.input {
    @apply mt-1 block w-full rounded-md border-gray-300 dark:border-neutral-700 dark:bg-neutral-800 dark:text-white shadow-sm focus:ring focus:ring-blue-500 focus:border-blue-500;
}
.btn-primary {
    @apply bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700;
}
</style><?php /**PATH D:\aps\ekonsulpkbi\resources\views\livewire/konselor-form.blade.php ENDPATH**/ ?>