<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard'))]); ?>
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <!-- Card Statistik -->
        <?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'ADMIN')): ?>
        <div class="grid auto-rows-min gap-4 md:grid-cols-3">
            <!-- Card Konselor (Biru) -->
            <div class="flex items-center gap-4 rounded-xl border border-blue-700 bg-blue-500 p-4 shadow-sm">
                <div class="flex h-12 w-12 items-center justify-center rounded-full bg-blue-800 text-white">
                    <?php echo e(svg('heroicon-o-user-group', 'w-12 h-12')); ?>
                </div>
                <div>
                    <div class="text-sm font-medium text-white">JUMLAH KONSELOR</div>
                    <div class="text-5xl font-bold text-white"><?php echo e($jumlahKonselor); ?></div>
                </div>
            </div>

            <!-- Card User (Kuning) -->
            <div class="flex items-center gap-4 rounded-xl border border-yellow-500 bg-yellow-500 p-4 shadow-sm">
                <div class="flex h-12 w-12 items-center justify-center rounded-full bg-yellow-700 text-white">
                    <?php echo e(svg('heroicon-o-user', 'w-12 h-12')); ?>
                </div>
                <div>
                    <div class="text-sm font-medium text-white">JUMLAH USER</div>
                    <div class="text-5xl font-bold text-white"><?php echo e($jumlahUser); ?></div>
                </div>
            </div>

            <!-- Card Diskon Aktif (Hijau) -->
            <div class="flex items-center gap-4 rounded-xl border border-green-500 bg-green-500 p-4 shadow-sm">
                <div class="flex h-12 w-12 items-center justify-center rounded-full bg-green-700 text-white">
                    <?php echo e(svg('heroicon-o-tag', 'w-12 h-12')); ?>
                </div>
                <div>
                    <div class="text-sm font-medium text-white">DISKON AKTIF</div>
                    <div class="text-5xl font-bold text-white"><?php echo e($jumlahDiskonAktif); ?></div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'USER')): ?>
        <div class="grid grid-cols-3 gap-4">
            <?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rounded-lg shadow-md bg-white p-4 hover:shadow-lg transition border border-blue-500">
                    <h3 class="text-lg font-semibold text-gray-800"><?php echo e($layanan->nama_layanan); ?></h3>
                    <p class="text-gray-600 line-through">Rp. <?php echo e(number_format($layanan->harga_layanan, 0, ',', '.')); ?> </p>
                    <p class="text-green-600 font-bold">Potongan Diskon 100%</p>
                    <p class="text-green-600 font-bold">Gunakan Kode Voucher: PKBIJAYA</p>
                    <a href="<?php echo e(route('dashboard.keranjang', ['id' => $layanan->id_layanan])); ?>" class="mt-2 w-full bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 flex items-center justify-center gap-2">
                        Mulai Konseling
                        <?php if (isset($component)) { $__componentOriginal0a0cf1bc116bd79ae77f26af29c340e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a0cf1bc116bd79ae77f26af29c340e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.chat-bubble-oval-left','data' => ['variant' => 'solid']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.chat-bubble-oval-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'solid']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a0cf1bc116bd79ae77f26af29c340e4)): ?>
<?php $attributes = $__attributesOriginal0a0cf1bc116bd79ae77f26af29c340e4; ?>
<?php unset($__attributesOriginal0a0cf1bc116bd79ae77f26af29c340e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a0cf1bc116bd79ae77f26af29c340e4)): ?>
<?php $component = $__componentOriginal0a0cf1bc116bd79ae77f26af29c340e4; ?>
<?php unset($__componentOriginal0a0cf1bc116bd79ae77f26af29c340e4); ?>
<?php endif; ?>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>


<?php /**PATH D:\aps\ekonsulpkbi\resources\views/dashboard.blade.php ENDPATH**/ ?>