<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('wirechat.modal');

$__html = app('livewire')->mount($__name, $__params, 'lw-928442951-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH D:\aps\ekonsulpkbi\storage\framework\views/63c67dc5d6924f41e6b1745a356eedd1.blade.php ENDPATH**/ ?>