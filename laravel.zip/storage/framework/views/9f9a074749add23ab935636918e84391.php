<div class="flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground">
    
    <img src="https://pkbi-jatim.or.id/wp-content/uploads/2021/12/cropped-Logo-PKBI-Jatim.png" alt="Logo" class="size-5 object-contain" />
</div>
<div class="ms-1 grid flex-1 text-start text-sm">
    <span class="mb-0.5 truncate leading-none font-semibold">Ekonsul PKBI</span>
</div>
<?php /**PATH D:\aps\ekonsulpkbi\resources\views/components/app-logo.blade.php ENDPATH**/ ?>