



<a href="<?php echo e(route('home')); ?>" class="flex aspect-square h-11 items-center justify-center rounded-md bg-accent-content text-accent-foreground">
    <img src="https://pkbi-jatim.or.id/wp-content/uploads/2023/02/logo-pkbi_JATIM-Baru.png" alt="Logo" class="h-11 p-1 w-auto object-contain" />
</a>

<?php /**PATH D:\aps\ekonsulpkbi\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>