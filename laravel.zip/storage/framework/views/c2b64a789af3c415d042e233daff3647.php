<div class="flex flex-col md:flex-row gap-6 p-6 dark:bg-gray-700 rounded-2xl shadow min-h-screen">

    <!-- Kolom Kiri: Form -->
    <div class="md:w-1/4 bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
        <h2 class="text-xl font-semibold mb-4 text-gray-800 dark:text-white">
            <?php echo e($updateMode ? 'Edit Diskon' : 'Tambah Diskon'); ?>

        </h2>

        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4 text-sm">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <form wire:submit.prevent="<?php echo e($updateMode ? 'update' : 'store'); ?>" class="space-y-4">

            <!-- Nama Diskon -->
            <div>
                <label class="block text-gray-700 dark:text-white">Nama Diskon</label>
                <input wire:model="nama_diskon" type="text" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_diskon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Kode Voucher -->
            <div>
                <label class="block text-gray-700 dark:text-white">Kode Voucher</label>
                <input wire:model="kode_voucher" type="text" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_voucher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Jumlah Diskon Harga -->
            <div>
                <label class="block text-gray-700 dark:text-white">Jumlah Diskon Harga</label>
                <input wire:model="jumlah_diskon_harga" type="number" step="0.01" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jumlah_diskon_harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Jumlah Diskon Persen -->
            <div>
                <label class="block text-gray-700 dark:text-white">Jumlah Diskon Persen</label>
                <input wire:model="jumlah_diskon_persen" type="number" step="0.01" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jumlah_diskon_persen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Status Aktiv -->
            <div>
                <label class="block text-gray-700 dark:text-white">Status Aktiv</label>
                <select wire:model="status_aktiv" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option class="dark: bg-gray-600" value="AKTIF">AKTIF</option>
                    <option class="dark: bg-gray-600" value="TIDAK AKTIF">TIDAK AKTIF</option>
                </select>
            </div>

            <!-- Submit Button -->
            <div class="flex gap-2">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    <?php echo e($updateMode ? 'Update' : 'Simpan'); ?>

                </button>
                <!--[if BLOCK]><![endif]--><?php if($updateMode): ?>
                    <button type="button" wire:click="resetForm" class="bg-gray-400 text-white px-4 py-2 rounded">Batal</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </form>
    </div>

    <!-- Kolom Kanan: Daftar Diskon -->
    <div class="md:w-3/4 bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
        <h2 class="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Daftar Diskon</h2>

        <!-- Pencarian -->
        <div class="flex flex-col md:flex-row gap-3 mb-4">
            <input
                wire:model.live.debounce.300ms="search"
                type="text"
                placeholder="Cari nama..."
                class="flex-1 border border-gray-300 rounded-lg px-3 py-2"
            />
        </div>

        <!-- Daftar Diskon -->
        <table class="w-full table-auto border border-gray-300 rounded">
            <thead class="bg-gray-100 dark:bg-gray-800">
                <tr>
                    <th class="p-2 text-left text-gray-600 dark:text-white">Nama Diskon</th>
                    <th class="p-2 text-left text-gray-600 dark:text-white">Kode Voucher</th>
                    <th class="p-2 text-left text-gray-600 dark:text-white">Potongan Persen</th>
                    <th class="p-2 text-left text-gray-600 dark:text-white">Potongan Harga</th>
                    <th class="p-2 text-left text-gray-600 dark:text-white">Status</th>
                    <th class="p-2 text-left text-gray-600 dark:text-white">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $diskons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo e($diskon->nama_diskon); ?></td>
                        <td class="p-2"><?php echo e($diskon->kode_voucher); ?></td>
                        <td class="p-2"><?php echo e($diskon->jumlah_diskon_persen); ?>%</td>
                        <td class="p-2">Rp. <?php echo e($diskon->jumlah_diskon_harga); ?></td>
                        <td class="p-2">
                            <!--[if BLOCK]><![endif]--><?php if($diskon->status_aktiv === 'AKTIF'): ?>
                                <span class="bg-green-500 text-green-800 text-sm px-2 py-1 rounded-full">AKTIF</span>
                            <?php else: ?>
                                <span class="bg-red-500 text-red-800 text-sm px-2 py-1 rounded-full">TIDAK AKTIF</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td class="p-2">
                            <!-- Edit & Delete Buttons -->
                            <button wire:click="edit(<?php echo e($diskon->id_diskon); ?>)" class="bg-yellow-500 text-white py-1 px-3 rounded hover:bg-yellow-600">Edit</button>
                            <button wire:click="delete(<?php echo e($diskon->id_diskon); ?>)" wire:confirm="Apakah Anda yakin ingin menghapus ini?" class="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600 ml-2">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>

        <!-- No Data Message -->
        <!--[if BLOCK]><![endif]--><?php if($diskons->isEmpty()): ?>
            <p class="text-gray-600 dark:text-white text-center mt-4">Tidak ada diskon yang tersedia.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH D:\aps\ekonsulpkbi\resources\views/livewire/dashboard/diskon-create.blade.php ENDPATH**/ ?>