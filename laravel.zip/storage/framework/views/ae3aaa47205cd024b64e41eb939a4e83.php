<?php if (isset($component)) { $__componentOriginal74e861309dfc9b9ab6d1aa2ec05b6057 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74e861309dfc9b9ab6d1aa2ec05b6057 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.error','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-center">
        <h1 class="text-4xl font-bold text-zinc-900 dark:text-white">Oops! Halaman tidak ditemukan</h1>
        <p class="text-zinc-600 dark:text-zinc-300 mt-2">Maaf, halaman yang Anda cari tidak tersedia.</p>
        <a href="<?php echo e(route('dashboard')); ?>" class="inline-block mt-6 px-4 py-2 text-white bg-blue-600 hover:bg-blue-700 rounded">Kembali ke Dashboard</a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74e861309dfc9b9ab6d1aa2ec05b6057)): ?>
<?php $attributes = $__attributesOriginal74e861309dfc9b9ab6d1aa2ec05b6057; ?>
<?php unset($__attributesOriginal74e861309dfc9b9ab6d1aa2ec05b6057); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74e861309dfc9b9ab6d1aa2ec05b6057)): ?>
<?php $component = $__componentOriginal74e861309dfc9b9ab6d1aa2ec05b6057; ?>
<?php unset($__componentOriginal74e861309dfc9b9ab6d1aa2ec05b6057); ?>
<?php endif; ?>
<?php /**PATH D:\aps\ekonsulpkbi\resources\views/errors/404.blade.php ENDPATH**/ ?>