<?php if (isset($component)) { $__componentOriginal4d86e4241fbd738058532a67df8b470d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d86e4241fbd738058532a67df8b470d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wirechat::components.notification','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wirechat::notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d86e4241fbd738058532a67df8b470d)): ?>
<?php $attributes = $__attributesOriginal4d86e4241fbd738058532a67df8b470d; ?>
<?php unset($__attributesOriginal4d86e4241fbd738058532a67df8b470d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d86e4241fbd738058532a67df8b470d)): ?>
<?php $component = $__componentOriginal4d86e4241fbd738058532a67df8b470d; ?>
<?php unset($__componentOriginal4d86e4241fbd738058532a67df8b470d); ?>
<?php endif; ?><?php /**PATH D:\aps\ekonsulpkbi\storage\framework\views/956a5b1e27cfd29398837729aea808ca.blade.php ENDPATH**/ ?>