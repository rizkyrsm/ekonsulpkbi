<?php echo $__env->make('Chatify::layouts.headLinks', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="messenger">
    
    <div class="messenger-listView <?php echo e(!!$id ? 'conversation-active' : ''); ?>">
        
        <div class="m-header">
            <nav>
                <input type="hidden" name="id_order" id="id_order" value="<?php echo e(request('id_order')); ?>">
                <a href="#"><i class="fas fa-inbox"></i> <span class="messenger-headTitle">EKONSUL</span> </a>
                
                <nav class="m-header-right">
                    <a href="#"><i class="fas fa-cog settings-btn"></i></a>
                    <a href="#" class="listView-x"><i class="fas fa-times"></i></a>
                </nav>
            </nav>
            
            <?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'ADMIN','KONSELOR','CABANG')): ?>
                <input type="text" class="messenger-search" placeholder="Search" />
            <?php endif; ?>
            
            
        </div>
        
        <div class="m-body contacts-container">
           
           
           <div class="show messenger-tab users-tab app-scroll" data-view="users">
               
               <div class="favorites-section">
                <p class="messenger-title"><span>Favorites</span></p>
                <div class="messenger-favorites app-scroll-hidden"></div>
               </div>
               
               
               
               <?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'ADMIN','KONSELOR','CABANG')): ?>
               <p class="messenger-title"><span>All Messages</span></p>
               <div class="listOfContacts" style="width: 100%;height: calc(100% - 272px);position: relative;"></div>
               <?php endif; ?>
           </div>
             
           <div class="messenger-tab search-tab app-scroll" data-view="search">
                
                <p class="messenger-title"><span>Search</span></p>
                <div class="search-records">
                    <p class="message-hint center-el"><span>Type to search..</span></p>
                </div>
             </div>
        </div>
    </div>

    
    <div class="messenger-messagingView">
        
        <div class="m-header m-header-messaging">
            <nav class="chatify-d-flex chatify-justify-content-between chatify-align-items-center">
                
                <div class="chatify-d-flex chatify-justify-content-between chatify-align-items-center">
                    
                    <div class="avatar av-s header-avatar" style="margin: 0px 10px; margin-top: -5px; margin-bottom: -5px;">
                    </div>
                    
                    <?php
                        $chatUser = \App\Models\User::with('detailUser')->find($id);
                    ?>
                    <a href="#" class=""><?php echo e($chatUser->detailUser->nama ?? $chatUser->name); ?></a>| <p>Layanan: <?php echo e(request('id_order')); ?></p>
                </div>
                
                <nav class="m-header-right">
                    <?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'ADMIN')): ?>
                    <a href="#" class="add-to-favorite"><i class="fas fa-star"></i></a>
                    <a href="/"><i class="fas fa-times"></i></a>
                    <a href="#" class="show-infoSide"><i class="fas fa-info-circle"></i></a>
                    <?php endif; ?>
                </nav>
            </nav>
            
            <div class="internet-connection">
                <span class="ic-connected">Connected</span>
                <span class="ic-connecting">Connecting...</span>
                <span class="ic-noInternet">No internet access</span>
            </div>
        </div>

        
        <div class="m-body messages-container app-scroll">
            <div class="messages">
                <p class="message-hint center-el"><span>Please select a chat to start messaging</span></p>
            </div>
            
            <div class="typing-indicator">
                <div class="message-card typing">
                    <div class="message">
                        <span class="typing-dots">
                            <span class="dot dot-1"></span>
                            <span class="dot dot-2"></span>
                            <span class="dot dot-3"></span>
                        </span>
                    </div>
                </div>
            </div>

        </div>
        
        <?php echo $__env->make('Chatify::layouts.sendForm', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    
    <?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'ADMIN')): ?>
    <div class="messenger-infoView app-scroll">
        
        <nav>
            <p>User Details</p>
            <a href="#"><i class="fas fa-times"></i></a>
        </nav>
        <?php echo view('Chatify::layouts.info')->render(); ?>

    </div>
    <?php endif; ?>
</div>

<?php echo $__env->make('Chatify::layouts.modals', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('Chatify::layouts.footerLinks', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\aps\ekonsulpkbi\resources\views/vendor/Chatify/pages/app.blade.php ENDPATH**/ ?>