<div>
    <h2>Daftar Chat</h2>

    <!--[if BLOCK]><![endif]--><?php if(!empty($contacts)): ?>
        <ul>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($contact['name']); ?> - Last chat: <?php echo e(\Carbon\Carbon::parse($contact['last_message_time'])->diffForHumans()); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    <?php else: ?>
        <p>Tidak ada conversation ditemukan.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH D:\aps\ekonsulpkbi\resources\views\livewire/dashboard/chat-list.blade.php ENDPATH**/ ?>