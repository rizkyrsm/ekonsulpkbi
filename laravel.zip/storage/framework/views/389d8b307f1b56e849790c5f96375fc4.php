<div class="flex flex-col md:flex-row gap-6 p-6 dark:bg-gray-700 rounded-2xl shadow min-h-screen">

    <?php
        $isInactive = Auth::user()->status === 'NONACTIVE';
    ?>
    <!--[if BLOCK]><![endif]--><?php if($isInactive): ?> <?php echo e('AKUN ANDA TIDAK AKTIV'); ?> <?php else: ?>

    

    
    <div class="md:w-1/4 bg-white dark:bg-gray-800 p-6 rounded-2xl shadow">
        <h2 class="text-2xl font-semibold mb-4 flex items-center gap-2">
            <!--[if BLOCK]><![endif]--><?php if($editingId): ?>
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-pencil'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-yellow-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                Edit User
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-user-plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-blue-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                Tambah User Baru
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </h2>

        <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4 text-sm">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <form wire:submit.prevent="submit" class="space-y-4">
            <div>
                <label class="block text-sm font-medium mb-1">Username</label>
                <input wire:model="name" type="text" class="w-full border border-gray-300 rounded-lg px-3 py-2" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <input wire:model="email" type="email" class="w-full border border-gray-300 rounded-lg px-3 py-2" <?php if($editingId): ?> disabled <?php endif; ?> />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div>
                <label class="block text-sm font-medium mb-1"><?php echo e($editingId ? 'Password Baru (opsional)' : 'Password'); ?></label>
                <input wire:model="password" type="password" class="w-full border border-gray-300 rounded-lg px-3 py-2" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">Role</label>
                <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'ADMIN')): ?>
                <select wire:model="role" class="w-full border border-gray-300 rounded-lg px-3 py-2">
                    <option class="dark: bg-gray-600" value="">Pilih Role</option>
                    <option class="dark: bg-gray-600" value="ADMIN">ADMIN</option>
                    <option class="dark: bg-gray-600" value="CABANG">CABANG</option>
                    
                </select>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'CABANG')): ?>
                <select wire:model="role" class="w-full border border-gray-300 rounded-lg px-3 py-2">
                    <option class="dark: bg-gray-600" value="">Pilih Role</option>
                    <option class="dark: bg-gray-600" value="KONSELOR">KONSELOR</option>
                </select>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="flex items-center gap-3">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700">
                    <?php echo e($editingId ? 'Update' : 'Simpan'); ?>

                </button>
                <!--[if BLOCK]><![endif]--><?php if($editingId): ?>
                    <button type="button" wire:click="resetForm" class="bg-gray-400 text-white px-4 py-2 rounded-xl">
                        Batal
                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </form>
    </div>

    <?php
        $userRole = Auth()->user()->role;
    ?>

    <!--[if BLOCK]><![endif]--><?php if($userRole === 'USER'): ?>
        <div class="text-center text-gray-600 text-lg mt-4">
            Riwayat Konseling
        </div>
    <?php else: ?>

    
    <div class="md:w-3/4 bg-white dark:bg-gray-800 p-6 rounded-2xl shadow">
        <h2 class="text-2xl font-semibold mb-4 flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-user-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-blue-700']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            Daftar User
        </h2>

        
        <div class="flex flex-col md:flex-row gap-3 mb-4">
            <input
                wire:model.live.debounce.300ms="search"
                type="text"
                placeholder="Cari nama/email..."
                class="flex-1 border border-gray-300 rounded-lg px-3 py-2"
            />
        </div>

        
        <table class="min-w-full text-sm text-left border">
            <thead class="bg-gray-100 text-gray-700 font-semibold">
                <tr>
                    <th class="py-2 px-3">Username</th>
                    <th class="py-2 px-3">Cabang</th>
                    <th class="py-2 px-3">Email</th>
                    <th class="py-2 px-3">Role</th>
                    <th class="py-2 px-3">Aksi</th>
                    <th class="py-2 px-3">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="py-2 px-3"><?php echo e($user->name); ?> </td>
                        <td class="py-2 px-3"><?php echo e($user->cabang_name ?? ''); ?> </td>
                        <td class="py-2 px-3"><?php echo e($user->email); ?></td>
                        <td class="py-2 px-3 capitalize"><?php echo e($user->role); ?></td>
                        <td class="py-2 px-3 space-x-2">
                            <button wire:click="edit(<?php echo e($user->id); ?>)" class="text-blue-600 hover:bg-sky-100 hover:underline"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-pencil-square'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-blue-700']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></button>
                            <button wire:click="delete(<?php echo e($user->id); ?>)" wire:confirm="Apakah Anda yakin ingin menghapus user ini?" class="text-red-600 hover:bg-red-100 hover:underline"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-red-700']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></button>
                        </td>
                        <td class="py-2 px-3 space-x-2">
                            <button wire:click="toggleStatus(<?php echo e($user->id); ?>)" class="text-sm px-2 py-1 rounded <?php echo e($user->status === 'ACTIVE' ? 'bg-green-500 text-white' : 'bg-red-400 text-white'); ?>">
                                <?php echo e($user->status === 'ACTIVE' ? 'ACTIVE' : 'NONACTIVE'); ?>

                            </button>
                        <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'CABANG')): ?>
                            <button wire:click="toggleStatusChat(<?php echo e($user->id); ?>)" class="text-sm px-2 py-1 rounded <?php echo e($user->status_online === 'online' ? 'bg-green-500 text-white' : 'bg-red-400 text-white'); ?>">
                                <i class="bi bi-wifi"></i> <?php echo e($user->status_online === 'online' ? 'online' : 'offline'); ?>

                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if (\Illuminate\Support\Facades\Blade::check('canRole', 'ADMIN')): ?>
                            <span class="text-sm px-2 py-1 rounded <?php echo e($user->status_online === 'online' ? 'bg-green-500 text-white' : 'bg-red-400 text-white'); ?>">
                                <?php echo e($user->status_online === 'online' ? 'online' : 'offline'); ?>

                            </span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="py-4 text-center text-gray-500">Tidak ada data ditemukan.</td></tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>

        
        <div class="mt-4">
            <?php echo e($users->links()); ?>

        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<?php /**PATH D:\aps\ekonsulpkbi\resources\views/livewire/dashboard/user-create.blade.php ENDPATH**/ ?>